create function fn_full_name(first_name character varying, last_name character varying) returns character varying
    language plpgsql
as
$$
    BEGIN
        RETURN concat($1, ' ', $2);
    end;
    $$;

alter function fn_full_name(varchar, varchar) owner to postgres;

